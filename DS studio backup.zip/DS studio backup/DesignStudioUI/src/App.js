import React, { Component, Fragment } from 'react';
import { BrowserRouter as Router, Route, Switch, Redirect } from 'react-router-dom';

import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css'
// import 'jquery/dist/jquery'

//Prime react css
import 'primereact/resources/themes/nova-light/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';

//Other imports
import axios from "axios";

//Import statements of Components
import Navbar from "./components/NavBar";
import RequestForm from "./components/RequestForm";
import EducatorHome from './components/EducatorHome';
import RequestCard from './components/RequestsCards';
import RequestDetailsTable from './components/RequestDetailsTable';
import Dialog  from './components/Dialog';

class App extends Component {

  state={ userName : "" }

  componentDidMount() {
    axios.get('http://localhost:4000/getUserName', {withCredentials : true})
    .then( res => this.setState({userName : res.data.username}) )
    .catch(error => {
      return error.response ? console.log(error.response.data.message) :console.log(error.message)
      }
    )
  }

  render() {
    return (
      <div>
        <Router>
          <Fragment>
            <Navbar userName={this.state.userName}/>
            <Switch>
              <Route exact path='/' render={()=><Dialog/>}/>
              {/* <Route exact path='/' render={()=><RequestCard userName={this.state.userName}/>}/> */}
              <Route exact path='/home' component={EducatorHome} />
              <Route exact path='/recordingRequest' render={()=><RequestForm userName={this.state.userName}/>}/>
              <Route path='*' render={() => <Redirect push to='/home' />} />
            </Switch>
          </Fragment>
        </Router>
      </div>
    );
  }
}

export default App;
