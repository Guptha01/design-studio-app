import React, { Component } from 'react';
import { Link } from "react-router-dom";
class EducatorHome extends Component {
    state = {}
    render() {
        return (
            <React.Fragment>
                <div className='text-center'>
                    <h5>Welcome to </h5>
                    <h1>ETA Design Studios</h1><br />
                    <Link to='/recordingRequest'><button className='btn btn-secondary btn-group-lg'>Log a Request</button></Link>
                </div>
            </React.Fragment>
        );
    }
}

export default EducatorHome;