import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableRow from '@material-ui/core/TableRow';

const useStyles = makeStyles(theme => ({
  root: {
    width: '100%',
    marginTop: theme.spacing(1),
    overflowX: 'auto',
  },
  table: {
    minWidth: 400,
  },
}));


export default function RequestDetailsTable() {
  const classes = useStyles();

  return (
    <div  className={classes.root}>
      <Table className={classes.table}>
        <TableBody>
        <TableRow>
              <TableCell  style={{ width : "100%"}}>Requestor Name</TableCell>
              <TableCell><b>Name</b></TableCell>
        </TableRow>
        <TableRow>
              <TableCell >Requestor Email Id</TableCell>
              <TableCell><b>Name</b></TableCell>
        </TableRow>
        <TableRow>
              <TableCell >Recording Name</TableCell>
              <TableCell><b>Name</b></TableCell>
        </TableRow>
        <TableRow>
              <TableCell >Recording Brief</TableCell>
              <TableCell><b>bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb
                  bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb</b></TableCell>
        </TableRow>
        <TableRow>
              <TableCell >Recording Type</TableCell>
              <TableCell><b>Name</b></TableCell>
        </TableRow>                               
        <TableRow>
              <TableCell >Recording Location</TableCell>
              <TableCell><b>Name</b></TableCell>
        </TableRow>  
        <TableRow>
              <TableCell >Script</TableCell>
              <TableCell>Download Button</TableCell>
        </TableRow>        
        <TableRow>
              <TableCell >Stage</TableCell>
              <TableCell>Stage name + Icon</TableCell>
        </TableRow>
        <TableRow>
              <TableCell >Allocated to:</TableCell>
              <TableCell><b>Name</b></TableCell>
        </TableRow> 
        <TableRow>
              <TableCell >Allocated on:</TableCell>
              <TableCell>Date</TableCell>
        </TableRow>                    
        </TableBody>
      </Table>
    </div>
  );
}