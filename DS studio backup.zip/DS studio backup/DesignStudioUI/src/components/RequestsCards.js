import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import CardContent from '@material-ui/core/CardContent';
import IconButton from '@material-ui/core/IconButton';
import Typography from '@material-ui/core/Typography';
import { red } from '@material-ui/core/colors';
import MoreVertIcon from '@material-ui/icons/MoreVert';
import 'typeface-roboto';

let data ={
    "_id": {
      "$oid": "5d8c165c1933601f74a4f8a9"
    },
    "comments": [],
    "requestId": "MYS201909263",
    "empName": "Guptha",
    "emailId": "Guptha@infosys.com",
    "title": "Node and Express",
    "brief": "Recording of Node course",
    "typeOfRecording": "Single Person Recording",
    "recordingLocation": "Mysore",
    "requestStatus": "true",
    "stages": {
      "preProduction": {
        "allocatedTo": "",
        "dateOfAllocation": "",
        "dateOfCompletion": ""
      },
      "production": {
        "allocatedTo": "",
        "dateOfAllocation": "",
        "dateOfCompletion": ""
      },
      "postProduction": {
        "allocatedTo": "",
        "dateOfAllocation": "",
        "dateOfCompletion": ""
      }
    },
    "createdAt": {
      "$date": "2019-09-26T01:37:32.269Z"
    },
    "updatedAt": {
      "$date": "2019-09-26T01:37:32.269Z"
    },
    "__v": 0
  }

const useStyles = makeStyles(theme => ({
  card: {
    maxWidth: 345,
  },
  media: {
    height: 0,
    paddingTop: '56.25%', // 16:9
  },
  expand: {
    transform: 'rotate(0deg)',
    marginLeft: 'auto',
    transition: theme.transitions.create('transform', {
      duration: theme.transitions.duration.shortest,
    }),
  },
  expandOpen: {
    transform: 'rotate(180deg)',
  },
  avatar: {
    backgroundColor: red[500],
  },
  cardHeader : {
      marginBottom : "-15px"
  }
}));

export default function RequestCard() {
  const classes = useStyles();
  const [expanded, setExpanded] = React.useState(false);

  const handleExpandClick = () => {
    setExpanded(!expanded);
  };

  return (
    <Card className={classes.card}>
      <CardHeader
        action={
          <IconButton aria-label="settings">
            <MoreVertIcon />
          </IconButton>
        }
        style={{marginBottom : '-7%'}}
        title={<b>{data.requestId}</b>}
        subheader={<small>September 14, 2016</small>}
      />
      <hr/>
      <CardContent style={{marginTop : '-7%'}}>
        <Typography variant='body1' component='data'>
        {data.title}  
        </Typography>
      </CardContent>
    </Card>
  );
}