import React, { Component } from "react";
import PropTypes from 'prop-types';
import Button from '@material-ui/core/Button';
import FormControl from '@material-ui/core/FormControl';
import Input from '@material-ui/core/Input';
import InputLabel from '@material-ui/core/InputLabel';
import Paper from '@material-ui/core/Paper';
import withStyles from '@material-ui/core/styles/withStyles';
import MenuItem from '@material-ui/core/MenuItem';
import Select from '@material-ui/core/Select';
import TextareaAutosize from '@material-ui/core/TextareaAutosize';
import axios from "axios";
import { CircularProgress } from "@material-ui/core";

const styles = theme => ({
  main: {
    width: 'auto',
    display: 'block', // Fix IE 11 issue.
    marginLeft: theme.spacing(3),
    marginRight: theme.spacing(3),
    [theme.breakpoints.up(400 + theme.spacing(3) * 2)]: {
      width: 400,
      marginLeft: 'auto',
      marginRight: 'auto',
    },
  },
  paper: {
    marginTop: theme.spacing(-3),
    display: 'flex',
    flexDirection: 'column',
    padding: `${theme.spacing(2)}px ${theme.spacing(3)}px ${theme.spacing(2)}px`,
  },
  submit: {
    marginTop: theme.spacing(6),
    alignSelf: "center"
  },
  title: {
    fontWeight: 'bold',
    color: 'white',
    backgroundColor: "#1976d2",
    padding: theme.spacing(2),
  },
});
let obj = { title: "", brief: "", typeOfRecording: true, recordingLocation: true }

class RequestForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      formValue: { ...obj },
      formErrorMessage: { ...obj },
      formValid: { ...obj, buttonActive: false },
      spinnerStatus: false,
      selectedFile: null,
      successMessage : "",
      errorMessage : ""
    };
  }

  componentDidMount() {
    this.setState({
      formValue: {
        ...obj,
        typeOfRecording: "Single Person Recording", recordingLocation: "Mysore"
      }
    })
  }

  onChangeHandler = event => {
    this.setState({ selectedFile: event.target.files[0] })
  }

  handleSubmit = event => {
    this.setState({ spinnerStatus: true })
    event.preventDefault();
    const data = new FormData()
    data.append('file', this.state.selectedFile)
    axios.post("http://localhost:4000/submit ", { ...this.state.formValue, empName: this.props.userName })
      .then(res => this.setState({ spinnerStatus: false, successMessage: res.data.message, errorMessage: "" }))
      .catch(error => {
        let message = error.response ? error.response.data.message : error.message
        this.setState({ spinnerStatus: false, errorMessage: message, successMessage: "" })
      })
  };

  handleChange = event => {
    let name = event.target.name
    let value = event.target.value
    const { formValue } = this.state
    this.setState({ formValue: { ...formValue, [name]: value } })
    this.validateField(name, value)
  };

  validateField = (fieldName, value) => {
    var { formValid } = this.state;
    var { formErrorMessage } = this.state;
    var message;

    switch (fieldName) {
      case 'title':
        value === "" ? message = "Please enter the title of the recording" : message = ""
        break;

      case "brief":
        value === "" ? message = "Please enter the brief of the recording" : message = ""
        break

      case "typeOfRecording":
        value === "" ? message = "Please select the type of recording" : message = ""
        break

      case "recordingLocation":
        value === "" ? message = "Please select your recording location" : message = ""
        break

      case "file":
        value === "" ? message = "Please upload a file" : message = ""
        break

      default:
        break;
    }

    //Form err message set
    formErrorMessage[fieldName] = message;
    this.setState({ formErrMsg: formErrorMessage });
    //Form Valid set
    message === "" ? formValid[fieldName] = true : formValid[fieldName] = false;
    formValid.buttonActive = formValid.title && formValid.brief && formValid.typeOfRecording
      && formValid.recordingLocation
    this.setState({ formValid: formValid });
  }

  render() {
    const { classes } = this.props;
    return (
      <React.Fragment>
        <div className="col-md-6 offset-3">
          <main className={classes.main}>
            <Paper>
              <h3 className={classes.title}>Log a Request</h3>
              <form className={classes.paper} onSubmit={this.handleSubmit}>

                <FormControl margin="normal" fullWidth>
                  <InputLabel htmlFor="title" >Recording Name</InputLabel>
                  <Input id="title" name="title"
                    onChange={this.handleChange} autoFocus />
                  <span name="titleError" className="text-danger">{this.state.formErrorMessage.title}</span>
                </FormControl>

                <InputLabel htmlFor="brief" style={{ marginTop: '5%', marginBottom: '-3%' }}>Recording Brief *</InputLabel>
                <FormControl margin="normal" required fullWidth style={{ marginBottom: '5%' }}>
                  <TextareaAutosize name='brief' id='brief' onChange={this.handleChange} aria-label="minimum height" rows={3} rowsMax={3} />
                  <span name="brief" className="text-danger">{this.state.formErrorMessage.brief}</span>
                </FormControl>

                <FormControl style={{ marginBottom: '-3%' }} fullWidth>
                  <InputLabel htmlFor="typeOfRecording">Recording Type</InputLabel>
                  <Select value={this.state.formValue.typeOfRecording} onChange={this.handleChange}
                    inputProps={{ name: 'typeOfRecording', id: 'typeOfRecording', }}>
                    <MenuItem value={"Single Person Recording"}>Single Person Recording</MenuItem>
                    <MenuItem value={"One on One Interview"}>One on One Interview</MenuItem>
                    <MenuItem value={"Panel Discussion"}>Panel Discussion</MenuItem>
                    <MenuItem value={"Live Broadcast"}>Live Broadcast</MenuItem>
                    <MenuItem value={"Audio Recording"}>Audio Recording</MenuItem>
                  </Select>
                  <span name="typeOfRecordingError" className="text-danger">{this.state.formErrorMessage.typeOfRecording}</span>
                </FormControl>

                <FormControl fullWidth style={{ marginTop: '8.5%', marginBottom: '-3%' }}>
                  <InputLabel htmlFor="recordingLocation">Recording Location</InputLabel>
                  <Select
                    value={this.state.formValue.recordingLocation}
                    onChange={this.handleChange}
                    inputProps={{
                      name: 'recordingLocation',
                      id: 'recordingLocation',
                    }}>
                    <MenuItem value={"Mysore"}>Mysore</MenuItem>
                    <MenuItem value={"Bangalore"}>Bangalore</MenuItem>
                    <MenuItem value={"Pune"}>Pune</MenuItem>
                    <MenuItem value={"Hyderabad"}>Hyderabad</MenuItem>
                  </Select>
                  <span name="recordingLocationError" className="text-danger">{this.state.formErrorMessage.recordingLocation}</span>
                </FormControl>

                {/* <input type="file" name="file" onChange={this.onChangeHandler}/> */}

                {!this.state.spinnerStatus ? <Button type="submit" fullWidth
                  variant="contained" color="primary" className={classes.submit}
                  disabled={!this.state.formValid.buttonActive}>
                  Submit
                </Button> : <CircularProgress className={classes.submit} />}
              <span name="recordingLocationError" className="text-danger">{this.state.errorMessage}</span>                                
              <span name="recordingLocationError" className="text-success">{this.state.successMessage}</span>              
              </form>
            </Paper>
          </main>
        </div>
      </React.Fragment>
    );
  }
}

RequestForm.propTypes = {
  classes: PropTypes.object.isRequired,
};

// export default connect(mapStateToProps)(Register)
export default withStyles(styles)(RequestForm)